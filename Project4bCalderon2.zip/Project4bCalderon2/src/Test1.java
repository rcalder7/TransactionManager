import java.util.*;

import it313.proj4.rcalder7.*;

public class Test1 {
	public static void main(String[] args) {
		Transaction trans1 = new Transaction(1001,"Ricardo Calderon", "Bob",33.55, "memo","ts");
		Transaction trans2 = new Transaction(13,"Berto Calderon", "Bob",33.55, "memo","ts");
// testing all methods in a traditional manner
		GoldTransaction goldTran = new GoldTransaction(1001,"Ricardo Calderon", "Bob",33.55, "memo","ts",4,5);
		LumberTransaction lumberTran = new LumberTransaction(1001,"Ricardo Calderon", "Bob",33.55, "memo","ts",4,5);
		System.out.println(trans1.get_id());
		System.out.println(trans1.get_seller());
		System.out.println(trans1.getBuyer());
		System.out.println(trans1.get_amount());
		System.out.println(trans1.get_memo());
		System.out.println(trans1.get_timestamp());
		System.out.println(trans1);
		
		System.out.println(goldTran.get_carats());
		System.out.println(goldTran.get_weight());
		System.out.println(goldTran);
		
		System.out.println(lumberTran.get_grade());
		System.out.println(lumberTran);
		//compared the two and recieved a 1
		
		System.out.println(trans1.compareTo(trans2));
		TransactionManager listOfReceipts =  new TransactionManager();
		Transaction hey = new Transaction(1001,"Ricardo Calderon", "Bob",33.55, "memo","ts");
		Transaction boy = new Transaction(1002,"Ricardo Calderon", "Bob",33.55, "memo","ts");

		listOfReceipts.add(hey);
		listOfReceipts.add(boy);
		
		//ArrayList<PurchaseReceipt> listofstuff = new ArrayList<PurchaseReceipt>( );
		
		//for(PurchaseReceipt ids: listofstuff ) {
			
		
			
		//}
		
		

		System.out.println(listOfReceipts.getAll())   ;

		
	}

}

