//Ricardo Calderon
//Project 4b, Transaction Manager
//Due Date 3/5/2019
//Submitted 3/5/2019


/**
 * Class that works with transaction Objects to manipulate lists 
 *
 * @author   Ricardo Calderon
 * @version  1.6 9/26/17     
 */
package it313.proj4.rcalder7;

import java.util.ArrayList;
import java.util.Collections;
import java.io.*;

@SuppressWarnings("serial")
public class TransactionManager implements Serializable {
	private ArrayList<PurchaseReceipt> _col;

	public TransactionManager() {

		_col = new ArrayList<PurchaseReceipt>();
	}
	/**
	 * add object to the arraylist              
	 * @param  none   
	 * @return none
	
	 */
	public void add(PurchaseReceipt pr) {

		_col.add(pr);

	}
	/**
	 * clears objects in the arraylist              
	 * @param  none   
	 * @return none
	
	 */
	public void clear() {
		_col.clear();
	}
	/**
	 * counts objects in the arraylist              
	 * @param  none   
	 * @return int
	
	 */
	public int getCount() {
		return _col.size();

	}
	/**
	 * shows objects in the arraylist              
	 * @param  none   
	 * @return arraylist
	
	 */
	public ArrayList<PurchaseReceipt> getAll() {

		ArrayList<PurchaseReceipt> output = new ArrayList<PurchaseReceipt>();
		for (PurchaseReceipt ids : _col) {

			output.add(ids);
		}

		Collections.sort(output);
		return  output;
	}
	/**
	 * finds the buyer inside the array list                 
	 * @param  String  
	 * @return arraylist
	 */
	public ArrayList<PurchaseReceipt> findBuyer(String buyerName) {
		ArrayList<PurchaseReceipt> output = new ArrayList<PurchaseReceipt>();
		for (PurchaseReceipt buyer : _col) {
			if(buyer.getBuyer().equals(buyerName)) {
			    output.add(buyer);
			}
		}

		Collections.sort(output);
		return  output;

	}

	/**
	 * finds the seller inside the array list                 
	 * @param  String  
	 * @return arraylist
	 */
	public ArrayList<PurchaseReceipt> findSeller(String sellerName) {
		ArrayList<PurchaseReceipt> output = new ArrayList<PurchaseReceipt>();
		for (PurchaseReceipt obj : _col) {
			if(obj.get_seller().contentEquals(sellerName)) {
			output.add(obj);
		}
	}
		Collections.sort(output);
		return output;

	}
	/**
	 * finds the id inside the array list                 
	 * @param  String  
	 * @return arraylist
	 */
	public PurchaseReceipt findId(int id) {
		for (PurchaseReceipt obj : _col) {
			if(id==obj.get_id()) {
			   return obj;
			}
		}
		return null;
	}
	/**
	 * saves into file for serilization                   

	   
	 */
	public void save( ) throws IOException {
        ObjectOutputStream outStream = new ObjectOutputStream(
                new FileOutputStream("receipts.ser"));
        outStream.writeObject(_col);
       System.out.println(_col);
        outStream.close( );
        
        
    }
	
	
	
	@SuppressWarnings("unchecked")
	public void load( ) throws IOException, ClassNotFoundException {
		ObjectInputStream inStream = new ObjectInputStream(
				new FileInputStream("receipts.ser"));
		_col = (ArrayList<PurchaseReceipt>) inStream.readObject( );
		inStream.close( );
	}
}