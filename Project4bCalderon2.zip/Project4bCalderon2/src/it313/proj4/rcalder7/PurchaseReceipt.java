//Ricardo Calderon
//Project 4b, Transaction Manager
//Due Date 3/5/2019
//Submitted 3/5/2019

package it313.proj4.rcalder7;

//interface that compares

public interface PurchaseReceipt extends Comparable<PurchaseReceipt> {
	
    public int get_id( );
    public String getBuyer( );
    public String get_seller();
    public double get_amount( );
    
    
    
   public int compareTo(PurchaseReceipt other);
}
