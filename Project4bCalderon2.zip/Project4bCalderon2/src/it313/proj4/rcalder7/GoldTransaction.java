//Ricardo Calderon
//Project 4b, Transaction Manager
//Due Date 3/5/2019
//Submitted 3/5/2019


/**
 * Class that works with gold transactions it is derived from the Transaction 
 *
 * @author   Ricardo Calderon
 * @version  1.6 9/26/17     
 */
package it313.proj4.rcalder7;

public class GoldTransaction extends Transaction  {
	
	private int _carats;
	private double _weight;
	
	public GoldTransaction(int theId, String theSeller, String theBuyer,double theAmt, String theMemo, 
			String theTs, int theCarats,double theWeight) {
		
		super(theId,theSeller,theBuyer, theAmt, theMemo,theTs);
		
		/**
		 * Value of Carats
		 */
		_carats = theCarats;
		/**
		 * the weight of the gold
		 */
		_weight = theWeight;
		
		
	}
	
	/** this gets the Carats from the object
	 * @param  none 
	 * @return return value of Carats 

	 */
	public int get_carats() {
		return _carats;
	}
	/** this gets the weight from the object
	 * @param  none 
	 * @return return value of weight 

	 */
	public double get_weight() {
		return _weight;
	}
	@Override
	public String toString() {
		return "GoldTransaction [_carats=" + _carats + ", _weight=" + _weight + "]";
	}
	

}
