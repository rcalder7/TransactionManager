
//Ricardo Calderon
//Project 4b, Transaction Manager
//Due Date 3/5/2019
//Submitted 3/5/2019
package it313.proj4.rcalder7;

import java.io.Serializable;


/**
 * Base class that contains the constructor for the following dereived classes gold and lumber 
 *
 * @author   Ricardo Calderon
 * @version  1.6 9/26/17     
 */
@SuppressWarnings("serial")
public class Transaction implements PurchaseReceipt, Serializable {
	// instance variables being made for transactions
	private int _id;
	private String _buyer;
	private String _seller;
	private double _amount;
	private String _memo;
	private String _timestamp; 
	
	// the constructor for transactions
	public Transaction(int theId, String theSeller, String theBuyer, double theAmt, String theMemo,String theTs ) {
		/**
		 * id of transaction
		 */
		_id = theId;
		/**
		 * Buyer name
		 */
		_buyer = theBuyer;
		/**
		 * seller name
		 */
		_seller=  theSeller;
		/**
		 * the amount
		 */
		_amount = theAmt;
		/**
		 *the memo
		 */
		_memo = theMemo;
		/**
		 * the timestamp
		 */
		_timestamp = theTs;
		
	}
// getters and setter for all instance variables
	
	/**this gets the id from the object

	 * Short one line description.                  
	 * @return return id value
	 */
	public int get_id() {
		return _id;
	}
	/**this gets the buyer from the object

	 * Short one line description.                  
	 * @return return buyer value
	 */
	public String getBuyer() {
		return _buyer;
	}
	/**this gets the seller from the object

	 * Short one line description.                  
	 * @return return seller value
	 */
	public String get_seller() {
		return _seller;
	}
	/**this gets the amount from the object

	 * Short one line description.                  
	 * @return return amount value
	 */
	public double get_amount() {
		return _amount;
	}
	/**this gets the memo from the object

	 * Short one line description.                  
	 * @return return memo value
	 */
	public String get_memo() {
		return _memo;
	}
	/**this gets the timestamp from the object

	 * Short one line description.                  
	 * @return return timestamp value
	 */
	public String get_timestamp() {
		return _timestamp;
	}

	@Override
	public String toString() {
		return "Transaction [_id=" + _id + ", _buyer=" + _buyer + ", _seller=" + _seller + ", _amount=" + _amount
				+ ", _memo=" + _memo + ", _timestamp=" + _timestamp + "]";
		
	} 
	


	
// compare to method where it is linked to the interface
	@Override
	public int compareTo(PurchaseReceipt other) {
		 if (this.get_id() > other.get_id()) {
	            return 1;
	        }
	        else if (this.get_id() < other.get_id()) {
	            return -1;
	        }
	        else {
	            return 0;
	        }
	}

}
