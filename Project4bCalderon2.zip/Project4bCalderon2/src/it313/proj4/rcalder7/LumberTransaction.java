//Ricardo Calderon
//Project 4b, Transaction Manager
//Due Date 3/5/2019
//Submitted 3/5/2019


/**
 * Class that works with lumber transactions it is derived from the Transaction 
 *
 * @author   Ricardo Calderon
 * @version  1.6 9/26/17     
 */
package it313.proj4.rcalder7;

public class LumberTransaction extends Transaction {
	
	
	//creation of instance variables grade and weight
	private int _grade;
	private double _weight; 
	
	public LumberTransaction(int theId, String theSeller, String theBuyer,double theAmt, String theMemo, 
			String theTs, int theGrade,double theWeight ) {
		// the parent class attributes are inherited
		super(theId,theSeller,theBuyer, theAmt, theMemo,theTs);
		
		/**
		 * the grade type for the wood inserted here
		 */
		_grade = theGrade;
		
		/**
		 * weight of the wood 
		 */
		_weight = theWeight;
		
		
		
	}
// getters 
	
	/**this gets the grade from the object

	 * Short one line description.                  
	 * @return return grade value
	 */
	public int get_grade() {
		return _grade;
	}
	/** this gets the weight from the object
	 * @param  none 
	 * @return return value of weight 

	 */
	public double get_weight() {
		return _weight;
	}
//string method that prints the grade and weight
	@Override
	public String toString() {
		return "LumberTransaction [_grade=" + _grade + ", _weight=" + _weight + "]";
	}
	
	
	
}
