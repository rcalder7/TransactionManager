//Ricardo Calderon
//Project 4b, Transaction Manager
//Due Date 3/5/2019
//Submitted 3/5/2019
import it313.proj4.rcalder7.*;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class Test2Test {
	private Transaction baseTran;
	private Transaction baseTran2;

	private GoldTransaction gold;
	private LumberTransaction lumber;

	@BeforeEach
	void setUp() throws Exception {
		
		baseTran = new Transaction (1001,"Ricardo Calderon", "Bob",33.55, "memo","ts");
		baseTran2 = new Transaction(13,"Berto Calderon", "Bob",33.55, "memo","ts");

		gold = new GoldTransaction(1001,"Ricardo Calderon", "Bob",33.55, "memo","ts",4,5);
		lumber = new LumberTransaction(1001,"Ricardo Calderon", "Bob",33.55, "memo","ts",4,5);
	}
//All test methods have been completed and tested for they all passed!
	@Test
	void test() {
		assertEquals(baseTran.get_id(),1001);
		assertEquals(baseTran.get_seller(), "Ricardo Calderon");
		assertEquals(baseTran.getBuyer(), "Bob");
		assertEquals(baseTran.get_amount(),33.55);
		assertEquals(baseTran.get_memo(),"memo");
		assertEquals(baseTran.get_timestamp(),"ts");


		assertEquals(gold.get_carats(),4);
		assertEquals(gold.get_weight(),5);


		assertEquals(lumber.get_grade(),4);
		assertEquals(baseTran.compareTo(baseTran2),1);
	}

}
