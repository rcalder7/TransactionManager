//Ricardo Calderon
//Project 4b, Transaction Manager
//Due Date 3/5/2019
//Submitted 3/5/2019
import java.io.IOException;
import java.util.*;

import it313.proj4.rcalder7.*;

public class Test3 {
	public static void main(String[] args) throws IOException {
	
		TransactionManager listOfTrans = new TransactionManager();
		
		Transaction trans1 = new Transaction(1001,"Ricardo Calderon", "fred",33.55, "memo","ts");
		
		Transaction trans2 = new Transaction(13,"Berto", "jeff",33.55, "memo","ts");
		
		Transaction trans3 = new Transaction(13,"Carl", "Bob",33.55, "memo","ts");


		//adding 2
		listOfTrans.add(trans1);
		listOfTrans.add(trans2);
		listOfTrans.add(trans3);

		
		// got 2 after adding 2
		System.out.println(listOfTrans.getCount());
		
		//System.out.print(listOfTrans.getAll());
		
		System.out.println();
		System.out.println();
		// finds buyer jeff
		System.out.println(listOfTrans.findBuyer("jeff"));
		//finds the id
		System.out.println(listOfTrans.findId(1001));
		//finds carl 
		System.out.println(listOfTrans.findSeller("Carl"));
		// saves serializble file 
		listOfTrans.save();


		

		
		
	
		

		
		
		
		
		
	}

}

